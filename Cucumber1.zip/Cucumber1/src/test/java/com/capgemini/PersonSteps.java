package com.capgemini;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class PersonSteps {
	
	private Person person = new Person();

	@Given("^that the person (.*)  wants to vote in election$")
	public void ageOfPerson(String name, int age) throws Throwable {
		person.setName(name);
		person.setAge(age);
		
	}
	
	@When("^ (.*) age is more then (\\d+) $")
	public void hisAge(String name, int age) throws Throwable {
		person.setName(name);
		person.setAge(age);
	}


	

	@Then("^ (.*) can vote $")
	public void certifiedYes(String name, int age) throws Throwable {
		assertThat(name, is(person.getName()));
		assertThat(person.getAge(), is(18));
		assertThat(person.canVote(), is(true));
	}





}
