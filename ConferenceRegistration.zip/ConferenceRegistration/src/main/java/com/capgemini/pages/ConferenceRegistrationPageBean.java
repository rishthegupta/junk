package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationPageBean {
	
	WebDriver driver;
	//Constructor
	public ConferenceRegistrationPageBean(WebDriver driver) {
		super();
		this.driver = driver;
		driver.get("C:\\Users\\RKUMA301\\Documents\\BDD\\ConferenceRegistration\\src\\main\\resources\\HtmlPages\\ConferenceRegistartion.html");
		PageFactory.initElements(driver, this);
	}
	
	//Web Elements
	
	@FindBy(xpath="//*[@id=\"txtFirstName\"]")
	WebElement firstNameBox;
	@FindBy(xpath="//*[@id=\"txtLastName\"]")
	WebElement lastNameBox;
	@FindBy(xpath="//*[@id=\"txtEmail\"]")
	WebElement emailBox;
	@FindBy(xpath="//*[@id=\"txtPhone\"]")
	WebElement contactNumberBox;
	@FindBy(xpath="/html/body/form/table/tbody/tr[5]/td[2]/select")
	WebElement noOfPeopleAttendingSelectBox;
	@FindBy(xpath="//*[@id=\"txtAddress1\"]")
	WebElement buildingNameBox;
	@FindBy(xpath="//*[@id=\"txtAddress2\"]")
	WebElement areaBox;
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	WebElement citySelectBox;
	@FindBy(xpath="/html/body/form/table/tbody/tr[10]/td[2]/select")
	WebElement stateSelectBox;
	@FindBy(xpath="/html/body/form/table/tbody/tr[12]/td[2]/input")
	WebElement accessMemberBox;
	@FindBy(xpath="/html/body/form/table/tbody/tr[13]/td[2]/input")
	WebElement accessNonMemberBox;
	@FindBy(xpath="/html/body/form/table/tbody/tr[14]/td/a")
	WebElement nextButton;
	
	
	//Setter Methods
	
	public void setFirstNAme(String firstName)
	{
		firstNameBox.sendKeys(firstName);
	}
	
	public void setLastName(String lastName)
	{
		lastNameBox.sendKeys(lastName);
	}
	
	public void setEmail(String email)
	{
		emailBox.sendKeys(email);
	}
	
	public void setContactNumber(String contatcNumber)
	{
		contactNumberBox.sendKeys(contatcNumber);
	}
	
	public void setNUmberOfPeople(String num)
	{
		new Select(noOfPeopleAttendingSelectBox).selectByVisibleText(num);
	}
	
	public void setBuilding(String venue)
	{
		buildingNameBox.sendKeys(venue);
	}
	
	public void setArea(String area)
	{
		areaBox.sendKeys(area);
	}
	
	public void setCity(String city)
	{
		new Select(citySelectBox).selectByVisibleText(city);
	}
	
	public void setState(String state)
	{
		new Select(stateSelectBox).selectByVisibleText(state);
	}
	
	public void setAccessType(String type)
	{
		if(type=="member")
		{
			accessMemberBox.click();
		}
		else
		{
			accessNonMemberBox.click();
		}
	}
	
	public void clickNext()
	{
		nextButton.click();
	}
	
	public void clearContatcNumber()
	{
		contactNumberBox.clear();
	}
	
	
}
