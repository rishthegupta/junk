package com.capgemini.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPageBean {

	
	WebDriver driver;
	
	//Constructor
	public PaymentDetailsPageBean(WebDriver driver) {
		super();
		this.driver = driver;
		driver.get("C:\\Users\\RKUMA301\\Documents\\BDD\\ConferenceRegistration\\src\\main\\resources\\HtmlPages\\PaymentDetails.html");
		PageFactory.initElements(driver, this);
	}
	
	
	//WebElements
	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	WebElement cardHolderNameBox;
	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	WebElement cardNumberBox;
	@FindBy(xpath="//*[@id=\"txtCvv\"]")
	WebElement cvvBox;
	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	WebElement expirationMonthBox;
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	WebElement expirationYearBox;
	@FindBy(xpath="//*[@id=\"btnPayment\"]")
	WebElement makePaymentButton;
	
	
	//Setter Methods
	
	public void setCardHolderName(String name)
	{
		cardHolderNameBox.sendKeys(name);
	}
	
	public void setCardNumvber(String cardNumber)
	{
		cardNumberBox.sendKeys(cardNumber);
	}
	
	
	public void setCVV(String cvv)
	{
		cvvBox.sendKeys(cvv);
	}
	
	public void setExpMonth(String month)
	{
		expirationMonthBox.sendKeys(month);
	}
	
	public void setExpYear(String year)
	{
		expirationYearBox.sendKeys(year);
	}
	
	public void clickPaymentButton()
	{
		makePaymentButton.click();
	}
	
	
	
	
	
	
}	
