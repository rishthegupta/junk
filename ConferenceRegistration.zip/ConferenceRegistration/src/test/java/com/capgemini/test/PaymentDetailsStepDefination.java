package com.capgemini.test;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import com.capgemini.driver.DriverClass;
import com.capgemini.pages.PaymentDetailsPageBean;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PaymentDetailsStepDefination {
	WebDriver driver;
	static PaymentDetailsPageBean paymentDetailsPageBean;
	
	@Given("^User is on Payment page$")
	public void user_is_on_Payment_page() {
		
		driver=DriverClass.getDriver();
		paymentDetailsPageBean=new PaymentDetailsPageBean(driver);
	}

	@When("^User Click 'Make Payment' button without entering 'Card holder name'$")
	public void user_Click_Make_Payment_button_without_entering_Card_holder_name() {
		paymentDetailsPageBean.clickPaymentButton();
	}

	@Then("^'Please fill the Card holder name' message should display$")
	public void please_fill_the_Card_holder_name_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the Card holder name",alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User Click 'Make Payment' button without entering 'Debit card Number'$")
	public void user_Click_Make_Payment_button_without_entering_Debit_card_Number() {
		paymentDetailsPageBean.setCardHolderName("Rishabh Kumar");
		paymentDetailsPageBean.clickPaymentButton();
	}

	@Then("^'Please fill the Debit card Number' message should display$")
	public void please_fill_the_Debit_card_Number_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the Debit card Number",alertMessage);
		driver.switchTo().alert().accept();
		
	}

	@When("^User Click 'Make Payment' button without entering 'Please fill the CVV Number'$")
	public void user_Click_Make_Payment_button_without_entering_Please_fill_the_CVV_Number() {
		paymentDetailsPageBean.setCardHolderName("Rishabh Kumar");
		paymentDetailsPageBean.setCardNumvber("9898787654356787");
		paymentDetailsPageBean.clickPaymentButton();
	}

	@Then("^'Please fill the CVV' message should display$")
	public void please_fill_the_CVV_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the CVV",alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User Click 'Make Payment' button without entering 'Expiration month'$")
	public void user_Click_Make_Payment_button_without_entering_Expiration_month() {
		paymentDetailsPageBean.setCardHolderName("Rishabh Kumar");
		paymentDetailsPageBean.setCardNumvber("9898787654356787");
		paymentDetailsPageBean.setCVV("878");
		paymentDetailsPageBean.clickPaymentButton();
	}

	@Then("^'Please fill expiration month' message should display$")
	public void please_fill_expiration_month_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill expiration month",alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User Click 'Make Payment' button without entering Expiration year'$")
	public void user_Click_Make_Payment_button_without_entering_Expiration_year(){
		paymentDetailsPageBean.setCardHolderName("Rishabh Kumar");
		paymentDetailsPageBean.setCardNumvber("9898787654356787");
		paymentDetailsPageBean.setCVV("878");
		paymentDetailsPageBean.setExpMonth("09");
		paymentDetailsPageBean.clickPaymentButton();
	}

	@Then("^'Please fill the expiration year' message should display$")
	public void please_fill_the_expiration_year_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the expiration year",alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User Click 'Make Payment' button after entering valid 'payment details'$")
	public void user_Click_Make_Payment_button_after_entering_valid_payment_details() {
		paymentDetailsPageBean.setCardHolderName("Rishabh Kumar");
		paymentDetailsPageBean.setCardNumvber("9898787654356787");
		paymentDetailsPageBean.setCVV("878");
		paymentDetailsPageBean.setExpMonth("09");
		paymentDetailsPageBean.setExpYear("23");
		paymentDetailsPageBean.clickPaymentButton();
	}

	@Then("^'Conference Room Booking successfully done!!!' message should display$")
	public void conference_Room_Booking_successfully_done_message_should_display() {
		
		
	}

}
