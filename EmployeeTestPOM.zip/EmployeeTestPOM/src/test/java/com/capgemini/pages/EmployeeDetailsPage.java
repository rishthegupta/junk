package com.capgemini.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class EmployeeDetailsPage {
	
	WebDriver driver;

	public EmployeeDetailsPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public void setEmployeeID(String employeeID)
	{
		driver.findElement(By.xpath("//*[@id=\"employeeID\"]")).sendKeys(employeeID);
	}
	
	public void setEmployeeName(String name)
	{
		driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys(name);
	}
	
	public void setCity(String city)
	{
		driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys(city);
	}
	
	public void setState(String state)
	{
		driver.findElement(By.xpath("//*[@id=\"state\"]")).sendKeys(state);
	}
	
	
	
	
	
	public void clickSubmit()
	{
		driver.findElement(By.xpath("//*[@id=\"employeeDetails\"]/table/tbody/tr[5]/th[1]/input")).click();
	}
	
	public void clickReset()
	{
		driver.findElement(By.xpath("//*[@id=\"reset\"]")).click();
	}
	
	
	public void fillDetails(String employeeID, String name, String city, String state)
	{
		
		setEmployeeID(employeeID);
		setEmployeeName(name);
		setCity(city);
		setState(state);
	}
	
	
	
	
	
	public String getTitleOfPage()
	{
		return driver.getTitle();
	}
	
	
	
	
	
	
}