package com.capgemini.test;


import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.openqa.selenium.WebDriver;

import com.capgemini.base.DriverBase;
import com.capgemini.pages.EmployeeDetailsPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EmployeeDetailsSteps {
	
	public static WebDriver driver;
	public static EmployeeDetailsPage employeeDetailsPage;
	
	@Before
	public void setup()
	{
		driver=DriverBase.getDriver();
		employeeDetailsPage= new EmployeeDetailsPage(driver);
	}
	
	
	
	
	
	@Given("^Open the Google Chrome and launch the application$")
	public void launch_the_details()
	{
		System.out.println("When called");
	}
	
	
	@When("^Enter the employeeID, name, city and state$")
	public void test_for_reset_button()
	{
		employeeDetailsPage.fillDetails("1001","Rishabh", "Pune", "Maharashtra");
	}
	
	@Then("^Reset the credential$")
	public void reset_credentials()
	{
		employeeDetailsPage.clickReset();
	}
	
	
	@When("^Enter the employeeID, name, city and state and click submit$")
	public void test_for_submit_button()
	{
		employeeDetailsPage.fillDetails("1001","Rishabh", "Pune", "Maharashtra");
	}
	
	@And("^If the details are correct$")
	public void if_details_are_corrrect()
	{
		System.out.println("And called");
	}
	
	@Then("^It should redirect to success page$")
	public void redirect_to_success()
	{
		employeeDetailsPage.clickSubmit();
		assertEquals("Success Page", employeeDetailsPage.getTitleOfPage());
	}
	

}
