package com.capgemini.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.exception.ProductDoesNotExistException;
import com.capgemini.models.Product;
import com.capgemini.service.IProductServiceImpl;

@RestController
public class ProductController {

	
	@Autowired
	IProductServiceImpl productService;
	
	//Mapped method for adding new product in Database.
	@PostMapping(value="/products/createProduct")
	public Product createProduct(@Valid @RequestBody Product product)
	{
		return productService.createProduct(product);
	}
	
	
	//Mapped method for updating existing product in Database. 
	@PutMapping(value="/products/updateProduct/{id}")
	public Product updatePrpduct(@Valid @PathVariable String id, @Valid @RequestBody Product product) throws ProductDoesNotExistException
	{
		return productService.updateProduct(id, product);
	}
	
	
	//Mapped method for deleting an existing product From Database, on the basis  of their Product ID.
	@DeleteMapping(value="/products/deleteProduct/{id}")
	public Product deleteProduct(@Valid @PathVariable String id ) throws ProductDoesNotExistException
	{
		return productService.deleteProduct(id);
	}
	
	//Mapped method for retrieving list of all existing products from Database.
	@GetMapping(value="/products/viewProducts")
	public List<Product> viewProducts()
	{
		return productService.viewProducts();
	}
	
	//Mapped method for finding an existing product From Database, on the basis  of their Product ID.
	@GetMapping(value="/products/findProduct/{id}")
	public Product findProduct(@Valid @PathVariable String id) throws ProductDoesNotExistException
	{
		return productService.findProduct(id);
	}
}
