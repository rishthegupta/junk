package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.exception.ProductDoesNotExistException;
import com.capgemini.models.Product;
import com.capgemini.repo.IProductRepo;


@Service
public class IProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo productRepo;
	
	
	@Override
	public Product createProduct(Product product) {
		
		return productRepo.createProduct(product);
		
	}

	@Override
	public Product updateProduct(String id, Product product) throws ProductDoesNotExistException {
		
		return productRepo.updateProduct(id, product);
		
	}

	@Override
	public Product deleteProduct(String id) throws ProductDoesNotExistException {
		
		return productRepo.deleteProduct(id);
	}

	@Override
	public List<Product> viewProducts() {
		
		return productRepo.viewProducts();
		
	}

	@Override
	public Product findProduct(String id) throws ProductDoesNotExistException {
		
		return productRepo.findProduct(id);
	}

}
