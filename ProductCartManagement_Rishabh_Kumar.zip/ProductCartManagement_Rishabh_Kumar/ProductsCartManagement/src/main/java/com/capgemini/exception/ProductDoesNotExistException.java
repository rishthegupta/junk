package com.capgemini.exception;

@SuppressWarnings("serial")
public class ProductDoesNotExistException extends Exception {

	public ProductDoesNotExistException(String messsage) {
		super(messsage);

}
}
