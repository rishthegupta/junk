package com.capgemini.models;

import javax.persistence.Entity;
import javax.persistence.Id;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Entity
public class Product {
	
	
	//Declarations
	@Id
	@Size(min=3, max=20, message="ID size should be between 3-20 characters")
	private String id;
	
	@NotNull(message=" This feild cannot be null")
	@Size(min=3, max=20, message="Name size should be between 3-20 characters")
	private String name;
	
	@NotNull(message=" This feild cannot be null")
	@Size(min=3, max=20, message="Model size should be between 3-20 characters")
	private String model;
	
	@NotNull(message=" This feild cannot be null")
	@Positive(message=" proce should be greater then or equal to 0")
	private double price;

	
	//Getter-Setter Methods
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	
	//Constructors
	

	public Product() {
		super();
	}

	public Product(@Size(min = 3, max = 20, message = "ID size should be between 3-20 characters") String id,
			@NotNull(message = " This feild cannot be null") @Size(min = 3, max = 20, message = "Name size should be between 3-20 characters") String name,
			@NotNull(message = " This feild cannot be null") @Size(min = 3, max = 20, message = "Model size should be between 3-20 characters") String model,
			@NotNull(message = " This feild cannot be null") @Positive(message = " proce should be greater then or equal to 0") double price) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.price = price;
	}
	
	
	
	
	

}
