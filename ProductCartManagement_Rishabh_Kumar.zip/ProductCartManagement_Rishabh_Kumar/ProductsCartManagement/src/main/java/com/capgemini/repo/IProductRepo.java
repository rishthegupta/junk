package com.capgemini.repo;

import java.util.List;

import com.capgemini.exception.ProductDoesNotExistException;
import com.capgemini.models.Product;


public interface IProductRepo {
	
	public Product createProduct(Product product);
	public Product updateProduct(String id, Product product) throws ProductDoesNotExistException;
	public Product deleteProduct(String id) throws ProductDoesNotExistException;
	public List<Product> viewProducts();
	public Product findProduct(String id) throws ProductDoesNotExistException;

}
