package com.capgemini.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.exception.ProductDoesNotExistException;

import com.capgemini.models.Product;


@Transactional
@Repository
public class IProductRepoImpl implements IProductRepo {

	@PersistenceContext
	EntityManager entityManager; //this will connect the application to database and and interact using primary key
	
	
	@Override
	public Product createProduct(Product product) {
		
		entityManager.persist(product); // This method will store the product details in a new row.
		entityManager.flush();
		return product;
	}

	@Override
	public Product updateProduct( String id,Product product) throws ProductDoesNotExistException {
		
		if(!product.getId().equals(id))
		{
			throw new ProductDoesNotExistException("Product with Product id "+id+" does not exist");
		}
		
		entityManager.merge(product); // This method will update the existing row id product with same product id.
		entityManager.flush();
		return product;
	}

	@Override
	public Product deleteProduct(String id) throws ProductDoesNotExistException {
		
		Product product=entityManager.find(Product.class,id);
		if(product==null)
		{
			throw new ProductDoesNotExistException("Product with Product id "+id+" does not exist");
		
		}
		
		entityManager.remove(product);
		entityManager.flush();
				
		return product;
	}

	@Override
	public List<Product> viewProducts() {
		TypedQuery<Product> query =entityManager.createQuery("SELECT product from Product product", Product.class);
		
		return query.getResultList();
	}

	@Override
	public Product findProduct(String id) throws ProductDoesNotExistException {

		Product product=entityManager.find(Product.class,id);
		
		if(product==null)
		{
			throw new ProductDoesNotExistException("Product with Product id "+id+" does not exist");
		}
		
		return product;
	}

}
