package com.capgemini;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EmployeeSteps {
	private static WebDriver driver;

	
	
	@Given("^Open the Google Chrome and launch the application$")				
    public void launch_the_application()							
    {	
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\RKUMA301\\Documents\\Selenium jar\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("C:\\Users\\RKUMA301\\Documents\\BDD\\EmployeeDetails\\htmlPages\\employeeDetails.html");
    }		

    @When("^Enter the employeeID, name, city and state$")					
    public void enter_the_details()  							
    {		
    	
       driver.findElement(By.xpath("//*[@id=\"employeeID\"]")).sendKeys("1001");
       driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("Rishabh Kumar");
       driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys("Pune");
       driver.findElement(By.xpath("//*[@id=\"state\"]")).sendKeys("Maharashtra");
       
    }		

    @Then("^Reset the credential$")					
    public void Reset_the_credential() 						
    {    		
    	
        driver.findElement(By.xpath("/html/body/center/form/table/tbody/tr[5]/th[2]/input")).click();				
    }		
    
    
    
    
    @When("^Enter the employeeID, name, city and state and click submit$")
    public void enter_the_details_for_submit()
    {
    	 driver.findElement(By.xpath("//*[@id=\"employeeID\"]")).sendKeys("1001");
         driver.findElement(By.xpath("//*[@id=\"name\"]")).sendKeys("Rishabh Kumar");
         driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys("Pune");
         driver.findElement(By.xpath("//*[@id=\"state\"]")).sendKeys("Maharashtra");
    }
    
    @When("^If the details are correct$")
    public void if_the_details_are_correct()  {
       System.out.println("nothing");
        
    }
    
    @Then("^It should redirect to success page$")
    public void redirect_to_success()
    {
    	driver.findElement(By.xpath("//*[@id=\"employeeDetails\"]/table/tbody/tr[5]/th[1]/input")).click();
    	assertEquals("file:///C:/Users/RKUMA301/Documents/BDD/EmployeeDetails/htmlPages/success.html", driver.getCurrentUrl());
    }


}
