package com.capgemini.pages;

public class SuccessPage {

}
