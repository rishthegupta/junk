package com.example.democlientappplp;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class WelcomeController {

	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	@RequestMapping("/")
	public String getResponse(ModelMap map){

			RestTemplate restTemplate = new RestTemplate(); 
			Response response = restTemplate.getForObject("http://localhost:8088/api/v1/response",Response.class);

			System.out.println(response);
			map.addAttribute("message",response);
			
			return "welcome";
			
		}

}
