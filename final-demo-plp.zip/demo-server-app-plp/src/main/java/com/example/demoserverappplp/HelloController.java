package com.example.demoserverappplp;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/v1/")
public class HelloController {

	
	@RequestMapping(value="response", method=RequestMethod.GET)
	public Response getResponse(){
		
		Result result = new Result();
		result.setAlpah3_code("IND");
		result.setAlpha2_code("IN");
		result.setName("INDIA");
		
		RestResponse restResponse = new RestResponse();
		
		restResponse.setMessages(new String[]{"More webservices are available at http://www.groupkt.com/post/f2129b88/services."});
		restResponse.setResult(result);
		
		Response response = new Response();
		response.setRestResponse(restResponse);
		
		return response;
	}
	
	
}
