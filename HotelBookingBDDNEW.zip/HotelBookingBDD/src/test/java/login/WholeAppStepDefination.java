package login;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.capgemini.driver.DriverClass;
import com.capgemini.pages.HotelBookingPage;
import com.capgemini.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.java.lu.a;

public class WholeAppStepDefination {
	
	
	
	private static WebDriver driver;
	private static HotelBookingPage hotelBookingPage;
	private static LoginPage loginPage;
	
	
	
	
	@Given("^User is on detail filling page$")
	public void user_is_on_detail_filling_page() {
		driver=DriverClass.getDriver();
		loginPage=new LoginPage(driver);
		hotelBookingPage=new HotelBookingPage(driver);
	
	}
	
	@When("^User enters corrrect credentials$")
	public void user_enters_corrrect_credentials()  {
		
		System.out.println("Reached when");
	    loginPage.fillLoginDetails("capgemini", "capg1234");
	    
	   
	}

	@Then("^he should be redirected to details filling page$")
	public void he_should_be_redirected_to_details_filling_page()  {
	    loginPage.clickLogin();
	    assertEquals("Hotel Booking", driver.getTitle());
	    
	}
	
	@When("^User select 'Next' link without entering 'FirstName'$")
	public void user_select_Next_link_without_entering_FirstName()  {
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		hotelBookingPage.confirmButton();
		
	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the First Name", alertMessage);
		driver.switchTo().alert().accept();
	}

	
	@When("^User select 'Next' link without entering 'LastName'$")
	public void user_select_Next_link_without_entering_LastName() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.confirmButton();
		
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() {
	    String alertMessage=driver.switchTo().alert().getText();
	    assertEquals("Please fill the Last Name", alertMessage);
	    driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without entering 'Email'$")
	public void user_select_Next_link_without_entering_Email() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.confirmButton();
	}

	@Then("^'Please fill the Email' message should display$")
	public void please_fill_the_Email_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the Email", alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link after entering invalid 'Email' address$")
	public void user_select_Next_link_after_entering_invalid_Email_address() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("asc");
		hotelBookingPage.confirmButton();
		
	}

	@Then("^'Please enter valid Email Id\\.' message should display$")
	public void please_enter_valid_Email_Id_message_should_display() {	
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please enter valid Email Id.", alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without entering 'Phone No'$")
	public void user_select_Next_link_without_entering_Phone_No() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.confirmButton();
	}

	@Then("^'Please fill the Mobile No\\.' message should display$")
	public void please_fill_the_Mobile_No_message_should_display() {
		
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the Mobile No.", alertMessage);
		
		driver.switchTo().alert().accept();
	}
	

	@When("^User select 'Next' link after entering invalid 'Contact No'$")
	public void user_select_Next_link_after_entering_invalid_Contact_No() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.setMobileNumber("9898");
		hotelBookingPage.confirmButton();
		
		
	}

	@Then("^'Please enter valid Contact no\\.' message should display$")
	public void please_enter_valid_Contact_no_message_should_display() {
		
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please enter valid Contact no.", alertMessage);
		driver.switchTo().alert().accept();
	}
	
	@When("^User select 'Next' link without selecting 'City'$")
	public void user_select_Next_link_without_selecting_City() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9999999999");
		hotelBookingPage.confirmButton();
		
	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please select city",alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without selecting 'State'$")
	public void user_select_Next_link_without_selecting_State() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9898989898");
		hotelBookingPage.setCity("Pune");
		hotelBookingPage.confirmButton();
		
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please select state", alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without entering 'Card Holder Name'$")
	public void user_select_Next_link_without_entering_Card_Holder_Name() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9898989898");
		hotelBookingPage.setCity("Pune");
		hotelBookingPage.setState("Maharashtra");
		hotelBookingPage.confirmButton();
	}

	@Then("^'Please fill the Card holder name' message should display$")
	public void please_fill_the_Card_holder_name_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the Card holder name", alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without entering 'Debit card number'$")
	public void user_select_Next_link_without_entering_Debit_card_number() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9898989898");
		hotelBookingPage.setCity("Pune");
		hotelBookingPage.setState("Maharashtra");
		hotelBookingPage.setCardHolderName("Rishabh Kumar");
		hotelBookingPage.confirmButton();
	}

	@Then("^'Please fill the Debit card Number' message should display$")
	public void please_fill_the_Debit_card_Number_message_should_display(){
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the Debit card Number", alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without entering 'CVV'$")
	public void user_select_Next_link_without_entering_CVV() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9898989898");
		hotelBookingPage.setCity("Pune");
		hotelBookingPage.setState("Maharashtra");
		hotelBookingPage.setCardHolderName("Rishabh Kumar");
		hotelBookingPage.setCardNumber("9898765456787654");
		hotelBookingPage.confirmButton();
	}

	@Then("^'Please fill the CVV' message should display$")
	public void please_fill_the_CVV_message_should_display(){
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the CVV", alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Next' link without entering 'Expiration Month'$")
	public void user_select_Next_link_without_entering_Expiration_Month() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9898989898");
		hotelBookingPage.setCity("Pune");
		hotelBookingPage.setState("Maharashtra");
		hotelBookingPage.setCardHolderName("Rishabh Kumar");
		hotelBookingPage.setCardNumber("9898765456787654");
		hotelBookingPage.setCVV("878");
		hotelBookingPage.confirmButton();
	}

	@Then("^'Please fill expiration month' message should display$")
	public void please_fill_expiration_month_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill expiration month", alertMessage);
		driver.switchTo().alert().accept();
		
	}

	@When("^User select 'Next' link without entering 'Expiration year'$")
	public void user_select_Next_link_without_entering_Expiration_year() {
		hotelBookingPage.setFirstName("Rishabh");
		hotelBookingPage.setLastName("Kumar");
		hotelBookingPage.setEmail("abc@xyz.com");
		hotelBookingPage.clearBox();
		hotelBookingPage.setMobileNumber("9898989898");
		hotelBookingPage.setCity("Pune");
		hotelBookingPage.setState("Maharashtra");
		hotelBookingPage.setCardHolderName("Rishabh Kumar");
		hotelBookingPage.setCardNumber("9898765456787654");
		hotelBookingPage.setCVV("878");
		hotelBookingPage.setExpYear("09");
		hotelBookingPage.confirmButton();
		
	}

	@Then("^'Please fill the expiration year' message should display$")
	public void please_fill_the_expiration_year_message_should_display() {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals("Please fill the expiration year",alertMessage);
		driver.switchTo().alert().accept();
	}

	@When("^User select 'Confirm' after entering valid details$")
	public void user_select_Confirm_after_entering_valid_details() {
		hotelBookingPage.fillPersonalDettails("Rishabh", "Kumar", "abc@xyz.com", "9898589589", "A Block", "Pune","Maharashtra", "2");
		hotelBookingPage.fillPaymentDetails("Rishabh Kumar","23246555677665673", "645", "08", "23");
		hotelBookingPage.confirmButton();
	}

	@Then("^Redirected to 'Success' Page$")
	public void redirected_to_Success_Page() {
		
		
		assertEquals("Payment Details", driver.getTitle());
	}
	
/*	@Given("^User is on login page, now he will login and enter details to book hotel$")
	public void user_is_on_login_page_now_he_will_login_and_enter_details_to_book_hotel() {
	   
		driver=DriverClass.getDriver();
		hotelBookingPage=new HotelBookingPage(driver);
		loginPage=new LoginPage(driver);
	}

	@When("^User will enter correct details$")
	public void user_will_enter_correct_details() {
	   
		loginPage.fillLoginDetails("capgemini", "capg1234");
		loginPage.clickLogin();
		hotelBookingPage.fillPersonalDettails("Rishabh", "Kumar", "abc@xyz.com", "9898589589", "A Block", "Pune","Maharashtra", "2");
		hotelBookingPage.fillPaymentDetails("Rishabh Kumar","23246555677665673", "645", "08", "23");
		    
		
	}

	@Then("^He will book hotel and redirected to success page$")
	public void he_will_book_hotel_and_redirected_to_success_page() {
	  
		hotelBookingPage.confirmButton();
		assertEquals("Payment Details", driver.getTitle());
	}

*/
}
