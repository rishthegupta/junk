package com.capgemini.model;


import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER")
public class Customer {

	private String customerName;
	@Id
	private String mobileNumber;
	@Embedded
	private Wallet wallet;
	
	
	
	
	//Getter-Setter
	public String getName() {
		return customerName;
	}
	public void setName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	
	//Constructor
	public Customer() {
		super();
	}
	public Customer(String customerName, String mobileNumber, Wallet wallet) {
		super();
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
		this.wallet = wallet;
	}

	//ToString
	@Override
	public String toString() {
		return "Customer [name=" + customerName + ", mobileNumber=" + mobileNumber + ", wallet=" + wallet + "]";
	}
	
	
	
	
	

}
