package com.capgemini.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Wallet {
	
	
	private BigDecimal balance;

	
	//Constructor
	public Wallet() {
		super();
	}

	public Wallet(BigDecimal balance) {
		super();
		this.balance = balance;
	}

	
	//Getter-Setter
	public BigDecimal getBalance() {
		return balance;
	}

	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	
	//ToString
	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}

	
	
}
