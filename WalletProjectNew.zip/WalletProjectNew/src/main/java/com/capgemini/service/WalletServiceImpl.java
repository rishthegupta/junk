package com.capgemini.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.model.Customer;
import com.capgemini.model.Wallet;
import com.capgemini.repo.WalletRepo;


@Service
public class WalletServiceImpl implements WalletService {
	

/*	public WalletServiceImpl() {
		super();
		
		walletRepo.save(new Customer("ABC", "9999999999", new Wallet(new BigDecimal("5000"))));
		walletRepo.save(new Customer("BCD", "8888888888", new Wallet(new BigDecimal("5000"))));
		walletRepo.save(new Customer("DEF", "7777777777", new Wallet(new BigDecimal("5000"))));
	}*/

	@Autowired
	WalletRepo walletRepo;


	@Override
	public boolean addAccount(String customerName, String mobileNumber, Double amount) {
		
		Customer customer=new Customer(customerName, mobileNumber,new Wallet(new BigDecimal(amount)));
		walletRepo.save(customer);
		return true;
	}
	
	@Override
	public Customer depositAmount(String mobileNumber, BigDecimal amount) {
		Customer customer =walletRepo.findById(mobileNumber).get();
		
		customer.getWallet().setBalance(customer.getWallet().getBalance().add(amount));
		walletRepo.save(customer);
		
		return null;
	}

	@Override
	public Customer withdrawAmount(String mobileNumber, BigDecimal amount) {
		Customer customer =walletRepo.findById(mobileNumber).get();
		customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(amount));
		walletRepo.save(customer);
		return null;
	}

	@Override
	public Customer fetchCustomer(String mobileNumber) {
		List<Customer> customersList=new ArrayList<>();
		
		walletRepo.findAll().forEach(customersList::add);
		
		for (Customer customer : customersList) {
			if(customer.getMobileNumber().equals(mobileNumber))
				return customer;
		}
		
		return null;

		
	}

	@Override
	public List<Customer> fetchAllCustomers() {
		List<Customer> customersList=new ArrayList<>();
		
		walletRepo.findAll().forEach(customersList::add);
		
		return customersList;
	}
	
	
	

}
