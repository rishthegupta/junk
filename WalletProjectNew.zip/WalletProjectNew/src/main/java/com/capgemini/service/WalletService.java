package com.capgemini.service;

import java.util.List;
import java.math.BigDecimal;

import com.capgemini.model.Customer;

public interface WalletService {

	
	
	public Customer depositAmount(String mobileNumber, BigDecimal amount);
	public Customer withdrawAmount(String mobileNumber, BigDecimal amount);
	public Customer fetchCustomer(String mobileNumber);
	public List<Customer> fetchAllCustomers();
	public boolean addAccount(String customerName, String mobileNumber, Double amount);
	
	

}
